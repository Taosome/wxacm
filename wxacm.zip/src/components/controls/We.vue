<template>
	<div id="we">
		
	</div>
</template>

<script>
	export default{
		name:"We"
	}
</script>

<style scoped="scoped" lang="scss">

</style>
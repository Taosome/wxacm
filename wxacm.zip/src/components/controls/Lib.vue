<template>
	<div id="lib">
		
	</div>
</template>

<script>
	export default{
		name:"Lib"
	}
</script>

<style scoped="scoped" lang="scss">

</style>
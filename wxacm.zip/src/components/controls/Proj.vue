<template>
	<div id="proj">
		
	</div>
</template>

<script>
	export default{
		name:"Proj"
	}
</script>

<style scoped="scoped" lang="scss">

</style>
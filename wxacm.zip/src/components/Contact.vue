<template>
	<div id="contact">
		
	</div>
</template>

<script>
	export default{
		name:"Contact"
	}
</script>

<style scoped="scoped" lang="scss">

</style>
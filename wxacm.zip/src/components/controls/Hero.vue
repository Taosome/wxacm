<template>
	<div id="hero">
		
	</div>
</template>

<script>
	export default{
		name:"Hero"
	}
</script>

<style scoped="scoped" lang="scss">

</style>
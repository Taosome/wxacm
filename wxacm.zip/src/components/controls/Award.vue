<template>
	<div id="award">
		
	</div>
</template>

<script>
	export default{
		name:"Award"
	}
</script>

<style scoped="scoped" lang="scss">

</style>